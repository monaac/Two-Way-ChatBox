document.getElementById('send-button').addEventListener('click', function() {
    const messageInput = document.getElementById('message-input');
    const messageText = messageInput.value.trim();
    
    if (messageText) {
        // Send the message
        addMessage('sent', messageText);
        
        // Simulate receiving a message
        setTimeout(() => {
            addMessage('received', 'This is a reply.');
        }, 1000);

        messageInput.value = '';
    }
});

function addMessage(type, text) {
    const messageElement = document.createElement('div');
    messageElement.classList.add('message', type);
    
    const messageContent = document.createElement('p');
    messageContent.textContent = text;
    messageElement.appendChild(messageContent);
    
    const messageTime = document.createElement('span');
    messageTime.classList.add('time');
    messageTime.textContent = new Date().toLocaleTimeString();
    messageElement.appendChild(messageTime);
    
    document.getElementById('chat-body').appendChild(messageElement);
    
    // Scroll to the bottom of the chat
    document.getElementById('chat-body').scrollTop = document.getElementById('chat-body').scrollHeight;
}
